
from odoo import models, fields, api

class SmtpConfig(models.Model):
    _name = 'smtp.config'
    _description = 'SMTP Configuration'

    name = fields.Char(string='SMTP Server Name', required=True)
    smtp_host = fields.Char(string='SMTP Host', required=True)
    smtp_port = fields.Integer(string='SMTP Port', required=True, default=587)
    smtp_user = fields.Char(string='SMTP User', required=True)
    smtp_pass = fields.Char(string='SMTP Password', required=True)
    smtp_encryption = fields.Selection([('none', 'None'), ('starttls', 'STARTTLS'), ('ssl', 'SSL/TLS')], string='SMTP Encryption', required=True, default='starttls')

    def configure_smtp_server(self):
        self.env['ir.mail_server'].create({
            'name': self.name,
            'smtp_host': self.smtp_host,
            'smtp_port': self.smtp_port,
            'smtp_user': self.smtp_user,
            'smtp_pass': self.smtp_pass,
            'smtp_encryption': self.smtp_encryption,
        })
